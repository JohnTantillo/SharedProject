package towers.model

object Level {

  def apply(number: Int): Level ={
    if(number == 0){
      new Level{
        startingLocation = new GridLocation(0, 4)
        base = new GridLocation(24, 4)
      }
    }else if(number == 1) {
      new Level {
        gridWidth = 10
        gridHeight = 20

        startingLocation = new GridLocation(1, 18)
        base = new GridLocation(6,7)
      }
    }else if(number == 2){
      new Level{
        gridWidth = 19
        gridHeight = 19

        startingLocation = new GridLocation(0, 18)
        base = new GridLocation(18, 0)

        maxBaseHealth = 30
      }
    }else{
      new Level
    }
  }

}

class Level {

  var towerLocations:List[GridLocation] = List()
  var wallLocations:List[GridLocation] = List()

  var gridWidth: Int = 25
  var gridHeight: Int = 9

  var startingLocation = new GridLocation(0, 3)
  var base = new GridLocation(24, 3)

  var maxBaseHealth = 2

}
