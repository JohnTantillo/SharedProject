package towers.model

object Level {

  def apply(number: Int): Level ={
    if(number == 0){
      new Level{
        startingLocation = new GridLocation(21, 9)
        base = new GridLocation(24, 4)
      }
    }else if(number == 1) {
      new Level {
        gridWidth = 10
        gridHeight = 10

        startingLocation = new GridLocation(21, 9)
        base = new GridLocation(24, 4)
      }
    }else if(number == 2){
      new Level{
        gridWidth = 10
        gridHeight = 10

        startingLocation = new GridLocation(21, 9)
        base = new GridLocation(24, 4)
      }
    }else{
      new Level
    }
  }

}

class Level {

  var towerLocations:List[GridLocation] = List()

  var gridWidth: Int = 10
  var gridHeight: Int = 10

  var startingLocation = new GridLocation(21, 9)
  var base = new GridLocation(1, 1)

}
