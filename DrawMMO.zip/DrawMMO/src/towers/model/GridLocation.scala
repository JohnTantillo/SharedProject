package towers.model

class GridLocation(val x: Int, val y: Int)
