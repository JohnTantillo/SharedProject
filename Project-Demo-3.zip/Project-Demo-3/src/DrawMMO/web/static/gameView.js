var socket = io.connect({transports: ['websocket']});
socket.on('gameState', parseGameState);

const tileSize = 30;

var canvas = document.getElementById("canvas");
var context = canvas.getContext("2d");
context.globalCompositeOperation = 'source-over';

function getRandomColor() {
    var letters = '0123456789ABCDEF';
    var color = '#';
    for (var i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}

function parseGameState(event) {
    // console.log(event);
    const gameState = JSON.parse(event);

    //placeSquare(gameState['start']['x'], gameState['start']['y'], '#ffffff');

    for (let player of gameState['players']) {
        placeCircle(player['x'], player['y'], player['id'] === socket.id ? getRandomColor() : getRandomColor(), 2.0);
    }
}

// function placeSquare(x, y, color) {
//     context.fillStyle = color;
//     context.fillRect(x * tileSize, y * tileSize, tileSize, tileSize);
//     context.strokeStyle = 'black';
//     context.strokeRect(x * tileSize, y * tileSize, tileSize, tileSize);
// }


function placeCircle(x, y, color, size) {
    context.fillStyle = color;
    context.beginPath();
    context.arc(x * tileSize,
        y * tileSize,
        size / 10.0 * tileSize,
        0,
        2 * Math.PI);
    context.fill();
    context.strokeStyle = 'black';
    context.stroke();
}

