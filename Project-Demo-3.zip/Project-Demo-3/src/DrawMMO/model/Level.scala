package DrawMMO.model

class Level {

  var gridWidth: Int = 10
  var gridHeight: Int = 10

  var startingLocation = new GridLocation(0, 0)

}
