package DrawMMO.model.physics

import DrawMMO.model.game_objects.PhysicalObject

object Physics {

  val EPSILON: Double = 1e-3

  def equalDoubles(d1: Double, d2: Double): Boolean = {
    (d1 - d2).abs < EPSILON
  }

  def computePotentialLocation(obj: PhysicalObject, dt: Double): PhysicsVector = {
    val newX = obj.location.x + dt * obj.velocity.x
    val newY = obj.location.y + dt * obj.velocity.y
    val newZ = 0.0.max(obj.location.z + dt * obj.velocity.z)
    if(newZ < EPSILON){
      obj.onGround()
    }
    new PhysicsVector(newX, newY, newZ)
  }

  def updateVelocity(obj: PhysicalObject, world: World, dt: Double): Unit = {
    val newZV = obj.velocity.z - world.gravity * dt
    if (obj.location.z < EPSILON && newZV < 0.0) {
      obj.velocity.z = 0.0
    } else {
      obj.velocity.z = newZV
    }
  }

  def slope(p1: PhysicsVector, p2: PhysicsVector): Double = {
    if(p2.x - p1.x == 0.0){
      1e5
//      Double.PositiveInfinity
    }else {
      (p2.y - p1.y) / (p2.x - p1.x)
    }
  }

  def yIntercept(p1: PhysicsVector, m: Double): Double = {
    p1.y - m * p1.x
  }


  def updateWorld(world: World, deltaTime: Double): Unit = {

    for (obj <- world.objects) {
      // update velocity
      updateVelocity(obj, world, deltaTime)

      // get potential location
      val potentialLocation = computePotentialLocation(obj, deltaTime)

      // check collisions
      var collisionDetected = false

      obj.location.z = potentialLocation.z
      if (!collisionDetected) {
        obj.location.x = potentialLocation.x
        obj.location.y = potentialLocation.y
      }

    }

    world.objects = world.objects.filter((po: PhysicalObject) => !po.destroyed)
  }

  }
