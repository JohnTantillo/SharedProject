package DrawMMO.model.physics

import DrawMMO.model.game_objects.PhysicalObject

class World(var gravity: Double) {

  var objects: List[PhysicalObject] = List()

}
